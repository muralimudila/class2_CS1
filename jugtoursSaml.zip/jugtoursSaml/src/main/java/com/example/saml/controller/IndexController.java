package com.example.saml.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.saml.provider.provisioning.SamlProviderProvisioning;
import org.springframework.security.saml.provider.service.ServiceProviderService;
import org.springframework.security.saml.saml2.attribute.Attribute;
import org.springframework.security.saml.spi.DefaultSamlAuthentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@Controller
public class IndexController {

	private SamlProviderProvisioning<ServiceProviderService> provisioning;

	@Value("${saml.discovery.url:/saml/sp/discovery}")
	private String samlDiscoveryUrl;

	//@Value("${saml.discovery.entity-id:https://sts.windows.net/4d6631f5-684f-4a10-a82e-0a03868083b9/}")
	@Value("${saml.discovery.entity-id}")
	private String samlDiscoveryEntityId;

	@Value("${saml.redirect.url}")
	private String samlRedirectURL;

	@Autowired
	public void setSamlService(SamlProviderProvisioning<ServiceProviderService> provisioning) {
		this.provisioning = provisioning;
	}

	@RequestMapping(value = {"/login"})
	public String home() {

		//model.addAttribute("samlLink", "0; url='"+ samlDiscoveryUrl + "?idp="+ samlDiscoveryEntityId+"'");
		return "redirect:"+samlDiscoveryUrl+"?idp="+samlDiscoveryEntityId;
	}

	@RequestMapping(value = {"/"})
	public String redirectToPortal(){

		//String redirectUrl = "https://localhost:3000";
		return "redirect:" + samlRedirectURL;
	}

	@GetMapping("/verifyUserAuthentication")
	public ResponseEntity<?> getUser(@AuthenticationPrincipal Authentication auth) {
		if(auth==null || (auth!=null && auth.getName().contains("anonymous")==true)) {
			return new ResponseEntity<>("", HttpStatus.OK);
		}
		else {
			DefaultSamlAuthentication  auth1 = (DefaultSamlAuthentication)auth;
			String emailAddress=null;
			for (Attribute a : auth1.getAssertion().getAttributes()) {
				System.out.println("Response XML: "+(a.getName().contains("emailaddress")==true?a.getValues().get(0):null));
				if(a.getName().contains("emailaddress")==true)
					emailAddress=(String)(a.getName().contains("emailaddress")==true?a.getValues().get(0):null);
			}
			return ResponseEntity.ok().body(emailAddress);
		}
	}


	@RequestMapping(value = {"/main"})
	public String main(){
		return "main";
	}

	@RequestMapping(value = {"/index", "/logged-in"})
	public String index() {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if (auth != null) {
			System.out.println("authenticated"+auth.getName());
			System.out.println("authenticated"+auth.getPrincipal());
			System.out.println("authenticated"+auth.getDetails());
		} else {
			System.out.println(" not authenticated");
		}
		return "logged-in";
	}

	@GetMapping("/api/user1")
	public ResponseEntity<?> getUser() {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if (auth == null) {
			return new ResponseEntity<>("", HttpStatus.OK);
		} else {
			System.out.println("authenticated"+auth.getName());
			return ResponseEntity.ok().body(auth.getName());
		}

	}
}
