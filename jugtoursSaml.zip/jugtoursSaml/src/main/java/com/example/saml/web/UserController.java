package com.example.saml.web;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.saml.saml2.attribute.Attribute;
import org.springframework.security.saml.spi.DefaultSamlAuthentication;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.security.Principal;
import java.util.HashMap;
import java.util.Map;

@ComponentScan
@RestController
public class UserController {


	@GetMapping("/api/user2")
	public ResponseEntity<?> getUser(@AuthenticationPrincipal Authentication auth) {
		if(auth==null || (auth!=null && auth.getName().contains("anonymous")==true)) {
			return new ResponseEntity<>("", HttpStatus.OK);
		}
		else {
			DefaultSamlAuthentication  auth1 = (DefaultSamlAuthentication)auth;
			System.out.println("authenticated"+auth1.getDetails());
			System.out.println("authenticated"+auth1.getPrincipal().toString());
			System.out.println("Response XML: "+auth1.getResponseXml());
			System.out.println("Response XML: "+auth1.getAssertion().getAttributes());
			String emailAddress=null;
			for (Attribute a : auth1.getAssertion().getAttributes()) {
				System.out.println("Response XML: "+(a.getName().contains("emailaddress")==true?a.getValues().get(0):null));
				if(a.getName().contains("emailaddress")==true)
				emailAddress=(String)(a.getName().contains("emailaddress")==true?a.getValues().get(0):null);
			}
			return ResponseEntity.ok().body(emailAddress);
		}


	}
	
	@PostMapping(value = {"/logout"})
	public String logout(){

		String redirectUrl = "/saml/sp/logout?local=true";
        return "redirect:" + redirectUrl;
	}


	@GetMapping("/api/test")
	public ResponseEntity<?> getTest() {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if (auth == null) {
			return new ResponseEntity<>("", HttpStatus.OK);
		} else {
			System.out.println("authenticated"+auth.getName());
			return  ResponseEntity.ok().body(auth.getName());
		}

	}

}